Page({
  onShareAppMessage() {
    return {
      title: 'icon',
      path: 'page/component/pages/icon/icon'
    }
  },
})

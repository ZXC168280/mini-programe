Page({
  onShareAppMessage() {
    return {
      title: 'navigator',
      path: 'page/component/pages/navigator/navigator'
    }
  }
})
